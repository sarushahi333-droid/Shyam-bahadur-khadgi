# वचन साथी — Netlify मा चलाउने तरिका

यो प्रारम्भिक चल्ने वेब एपको प्रोजेक्ट हो। यसमा मोबाइलमैत्री इन्टरफेस, नेपाली/अंग्रेजी/हिन्दी UI, प्रवचन AI फर्म, पद अध्ययन AI फर्म, YouTube embed player, स्थानीय प्रवचन सेभ, JSON backup/restore र PWA फाइलहरू छन्।

## १. Netlify मा Deploy गर्ने

**सजिलो तरिका (Static deploy):**
1. ZIP खोल्नुहोस्।
2. `vachan-sathi` फोल्डरका फाइलहरू Netlify Drop मा अपलोड गर्नुहोस्: https://app.netlify.com/drop
3. वेबसाइट खुल्नेछ। तर AI function चलाउन Netlify Functions deploy गर्न Git वा Netlify CLI बाट deploy गर्नुपर्छ।

**Functions सहित पूरा Deploy (सिफारिस):**
1. यो फोल्डर GitHub repository मा अपलोड गर्नुहोस्।
2. Netlify मा `Add new site` → `Import an existing project` छान्नुहोस्।
3. GitHub repository जोड्नुहोस्।
4. Publish directory `.` राख्नुहोस्।
5. Netlify deploy गर्नुहोस्।

## २. Gemini AI जडान गर्ने

1. Google AI Studio बाट Gemini API key बनाउनुहोस्।
2. Netlify Site configuration → Environment variables मा जानुहोस्।
3. `GEMINI_API_KEY` नाम र आफ्नो API key value राख्नुहोस्।
4. Site redeploy गर्नुहोस्।

API key कहिल्यै `app.js` वा सार्वजनिक HTML फाइलमा नराख्नुहोस्। Function ले मात्र पढ्छ।

## ३. भिडियो सुविधा

भिडियो पृष्ठमा YouTube URL वा भिडियो ID राख्दा समर्थित भिडियो एपभित्रै प्ले हुन्छ। भिडियो मालिकले embedding बन्द गरेको भए YouTube मा खोल्नुपर्ने हुन्छ। हालको संस्करणमा विषय बटनले YouTube खोजी पृष्ठ खोल्छ; एपभित्र खोज परिणाम देखाउन YouTube Data API र छुट्टै Netlify Function थप्नुपर्छ।

## ४. डेटा सुरक्षा

प्रवचनहरू हाल प्रयोगकर्ताको ब्राउजरको `localStorage` मा सुरक्षित हुन्छन्। JSON backup/restore उपलब्ध छ। ब्राउजर डेटा मेटिएमा सामग्री हराउन सक्छ, त्यसैले ब्याकअप नियमित निकाल्नुहोस्। यो संस्करणमा cloud sync वा user login समावेश छैन।

## ५. APK बनाउने

यो ZIP वेबसाइट/PWA हो; आफैँमा APK फाइल होइन। APK बनाउन:
1. कम्प्युटरमा Node.js र Android Studio स्थापना गर्नुहोस्।
2. प्रोजेक्टमा Capacitor जोड्नुहोस् (`@capacitor/core`, `@capacitor/cli`, `@capacitor/android`)।
3. वेब प्रोजेक्टलाई build output फोल्डरमा राखेर Capacitor को `webDir` सेट गर्नुहोस्।
4. `npx cap add android` र `npx cap sync android` चलाउनुहोस्।
5. `npx cap open android` बाट Android Studio खोल्नुहोस्।
6. Android Studio बाट Build → Generate Signed Bundle / APK प्रयोग गर्नुहोस्।

## सीमितता

- Bible को ६६ पुस्तकको पूरा पाठ यस ZIP मा समावेश छैन। प्रतिलिपि अधिकार अनुमति भएको Bible API वा तपाईंको इजाजतप्राप्त पाठ स्रोत जोड्नुपर्छ।
- AI उत्तरहरू अध्ययन सहयोगका लागि हुन्; प्रवचनमा प्रयोग गर्नुअघि बाइबलको अधिकृत संस्करण र विश्वसनीय अध्ययन स्रोतबाट सन्दर्भ जाँच्नुहोस्।
- यो प्रारम्भिक संस्करण हो; उत्पादनमा लैजानुअघि उपकरण र मोबाइल ब्राउजरमा परीक्षण गर्नुहोस्।
