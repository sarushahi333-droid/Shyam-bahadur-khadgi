// Netlify Function: Gemini API proxy. Keep GEMINI_API_KEY in Netlify environment variables.
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method Not Allowed" };
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return { statusCode: 503, body: JSON.stringify({ error: "AI setup is incomplete. Add GEMINI_API_KEY in Netlify environment variables." }) };
  try {
    const body = JSON.parse(event.body || "{}");
    const { task, payload = {}, language = "ne" } = body;
    const languageName = ({ ne: "Nepali", en: "English", hi: "Hindi" })[language] || "Nepali";
    let instruction = "";
    if (task === "sermon") {
      instruction = `Prepare a thorough Bible-based sermon study draft in ${languageName}. Topic: ${payload.topic || ""}. Main passage: ${payload.passage || "Suggest a relevant passage and clearly label it as a suggestion"}. Duration: ${payload.duration || "30 minutes"}. Style: ${payload.style || "Expository"}. Audience: ${payload.audience || "General congregation"}.
Structure it with title, main passage, introduction, historical and literary context, careful passage explanation, 3-5 preaching points, supporting references with explanations, biblical illustrations, practical applications, reflection questions, conclusion, invitation/challenge, and closing prayer. Do not fabricate quotations or claim unverified facts. Distinguish direct Scripture from interpretation. If you cannot verify a reference or its wording, say so and ask the reader to check an authorized Bible translation. Respect the context of every passage.`;
    } else if (task === "verse") {
      instruction = `Provide a careful Bible study in ${languageName} for this reference: ${payload.reference || ""}. Include likely passage identification, context before and after, historical/literary background where established, explanation, key terms if relevant, cross references, theological observations, practical application, and sermon use. Do not invent the exact Bible text or pretend to quote a translation you cannot access. If the reference is ambiguous, explain the ambiguity and ask for clarification.`;
    } else {
      return { statusCode: 400, body: JSON.stringify({ error: "Unsupported AI task." }) };
    }
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(apiKey), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: instruction }] }], generationConfig: { temperature: 0.35, maxOutputTokens: 7000 } })
    });
    const result = await response.json();
    if (!response.ok) return { statusCode: response.status, body: JSON.stringify({ error: result.error?.message || "Gemini request failed." }) };
    const text = result.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("\n") || "";
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: "Server error while generating the study." }) };
  }
};